from django.contrib import admin
from .models import Hotel,Orders1,Reservation,Reserve,Book,Room,Comment,FoodOrder
# Register your models here.
admin.site.register(Hotel)
admin.site.register(Orders1)
admin.site.register(Reservation)
admin.site.register(Reserve)
admin.site.register(Book)
admin.site.register(Room)
admin.site.register(Comment)
admin.site.register(FoodOrder)
