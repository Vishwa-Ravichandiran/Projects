A web appilcation for reservation of rooms in hotel which is developed using Django
